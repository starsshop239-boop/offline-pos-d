import { Product, Sale, Restock } from "@shared/schema";

const PRODUCTS_KEY = "pos_products";
const SALES_KEY = "pos_sales";
const RESTOCKS_KEY = "pos_restocks";

// Products
export const getProducts = (): Product[] => {
  const data = localStorage.getItem(PRODUCTS_KEY);
  return data ? JSON.parse(data) : [];
};

export const saveProducts = (products: Product[]): void => {
  localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
};

export const getProduct = (id: string): Product | undefined => {
  const products = getProducts();
  return products.find((p) => p.id === id);
};

export const addProduct = (product: Product): void => {
  const products = getProducts();
  products.push(product);
  saveProducts(products);
};

export const updateProduct = (id: string, updates: Partial<Product>): void => {
  const products = getProducts();
  const index = products.findIndex((p) => p.id === id);
  if (index !== -1) {
    products[index] = { ...products[index], ...updates };
    saveProducts(products);
  }
};

export const deleteProduct = (id: string): void => {
  const products = getProducts();
  const filtered = products.filter((p) => p.id !== id);
  saveProducts(filtered);
};

// Sales
export const getSales = (): Sale[] => {
  const data = localStorage.getItem(SALES_KEY);
  return data ? JSON.parse(data) : [];
};

export const saveSales = (sales: Sale[]): void => {
  localStorage.setItem(SALES_KEY, JSON.stringify(sales));
};

export const addSale = (sale: Sale): void => {
  const sales = getSales();
  sales.push(sale);
  saveSales(sales);
};

// Restocks
export const getRestocks = (): Restock[] => {
  const data = localStorage.getItem(RESTOCKS_KEY);
  return data ? JSON.parse(data) : [];
};

export const saveRestocks = (restocks: Restock[]): void => {
  localStorage.setItem(RESTOCKS_KEY, JSON.stringify(restocks));
};

export const addRestock = (restock: Restock): void => {
  const restocks = getRestocks();
  restocks.push(restock);
  saveRestocks(restocks);
};

// Clear all data (for testing)
export const clearAllData = (): void => {
  localStorage.removeItem(PRODUCTS_KEY);
  localStorage.removeItem(SALES_KEY);
  localStorage.removeItem(RESTOCKS_KEY);
};

// Re-export types for convenience
export type { Product, Sale, Restock } from "@shared/schema";
