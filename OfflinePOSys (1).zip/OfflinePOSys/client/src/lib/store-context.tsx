import { createContext, useContext, useState, useCallback, useEffect, ReactNode } from "react";
import { getProducts, getSales, getRestocks, Product, Sale, Restock } from "@/lib/localStorage";

interface StoreContextType {
  products: Product[];
  sales: Sale[];
  restocks: Restock[];
  refreshProducts: () => void;
  refreshSales: () => void;
  refreshRestocks: () => void;
  refreshAll: () => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>(getProducts());
  const [sales, setSales] = useState<Sale[]>(getSales());
  const [restocks, setRestocks] = useState<Restock[]>(getRestocks());

  const refreshProducts = useCallback(() => {
    setProducts(getProducts());
  }, []);

  const refreshSales = useCallback(() => {
    setSales(getSales());
  }, []);

  const refreshRestocks = useCallback(() => {
    setRestocks(getRestocks());
  }, []);

  const refreshAll = useCallback(() => {
    setProducts(getProducts());
    setSales(getSales());
    setRestocks(getRestocks());
  }, []);

  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === "pos_products" || e.key === null) {
        refreshProducts();
      }
      if (e.key === "pos_sales" || e.key === null) {
        refreshSales();
      }
      if (e.key === "pos_restocks" || e.key === null) {
        refreshRestocks();
      }
    };

    window.addEventListener("storage", handleStorageChange);

    return () => {
      window.removeEventListener("storage", handleStorageChange);
    };
  }, [refreshProducts, refreshSales, refreshRestocks]);

  return (
    <StoreContext.Provider
      value={{
        products,
        sales,
        restocks,
        refreshProducts,
        refreshSales,
        refreshRestocks,
        refreshAll,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error("useStore must be used within StoreProvider");
  }
  return context;
}
