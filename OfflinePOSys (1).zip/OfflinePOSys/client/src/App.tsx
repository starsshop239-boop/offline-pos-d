import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { StoreProvider } from "@/lib/store-context";
import SalesPage from "@/pages/sales";
import ProductsPage from "@/pages/products";
import InventoryPage from "@/pages/inventory";
import ReportsPage from "@/pages/reports";
import TransactionsPage from "@/pages/transactions";

function Router() {
  return (
    <Switch>
      <Route path="/">{() => <SalesPage />}</Route>
      <Route path="/products">{() => <ProductsPage />}</Route>
      <Route path="/inventory">{() => <InventoryPage />}</Route>
      <Route path="/reports">{() => <ReportsPage />}</Route>
      <Route path="/transactions">{() => <TransactionsPage />}</Route>
    </Switch>
  );
}

export default function App() {
  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <StoreProvider>
          <SidebarProvider style={style as React.CSSProperties}>
            <div className="flex h-screen w-full">
              <AppSidebar />
              <div className="flex flex-col flex-1">
                <header className="flex items-center gap-2 p-4 border-b">
                  <SidebarTrigger data-testid="button-sidebar-toggle" />
                  <h2 className="text-lg font-semibold">Point of Sale System</h2>
                </header>
                <main className="flex-1 overflow-auto p-6">
                  <Router />
                </main>
              </div>
            </div>
          </SidebarProvider>
          <Toaster />
        </StoreProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}
