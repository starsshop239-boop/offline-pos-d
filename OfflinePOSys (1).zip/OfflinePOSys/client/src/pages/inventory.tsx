import { useState } from "react";
import { Package, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { updateProduct, addRestock } from "@/lib/localStorage";
import { Product } from "@shared/schema";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useStore } from "@/lib/store-context";

export default function InventoryPage() {
  const { products, refreshProducts, refreshRestocks } = useStore();
  const [restockingProduct, setRestockingProduct] = useState<Product | null>(null);
  const [restockQuantity, setRestockQuantity] = useState("");
  const { toast } = useToast();

  const lowStockProducts = products.filter(
    (p) => p.currentStock <= p.lowStockThreshold && p.currentStock > 0
  );
  const outOfStockProducts = products.filter((p) => p.currentStock === 0);

  const handleRestock = () => {
    if (!restockingProduct || !restockQuantity) return;

    const qty = parseInt(restockQuantity);
    if (qty <= 0) {
      toast({
        title: "Invalid Quantity",
        description: "Please enter a valid quantity.",
        variant: "destructive",
      });
      return;
    }

    const newStock = restockingProduct.currentStock + qty;
    updateProduct(restockingProduct.id, { currentStock: newStock });

    addRestock({
      id: Date.now().toString(),
      productId: restockingProduct.id,
      productCode: restockingProduct.code,
      productName: restockingProduct.name,
      quantity: qty,
      date: new Date().toISOString(),
    });

    toast({
      title: "Stock Updated",
      description: `Added ${qty} units to ${restockingProduct.name}`,
    });

    setRestockingProduct(null);
    setRestockQuantity("");
    refreshProducts();
    refreshRestocks();
  };

  const totalProducts = products.length;
  const totalValue = products.reduce((sum, p) => sum + p.currentStock * p.price, 0);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-semibold" data-testid="text-page-title">Inventory Management</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Products</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-total-products">{totalProducts}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Inventory Value</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-inventory-value">${totalValue.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Low Stock Items</CardTitle>
            <AlertTriangle className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600" data-testid="text-low-stock-count">
              {lowStockProducts.length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Out of Stock</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive" data-testid="text-out-of-stock-count">
              {outOfStockProducts.length}
            </div>
          </CardContent>
        </Card>
      </div>

      {(lowStockProducts.length > 0 || outOfStockProducts.length > 0) && (
        <Card>
          <CardHeader>
            <CardTitle>Stock Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {outOfStockProducts.map((product) => (
                <div
                  key={product.id}
                  className="flex items-center justify-between p-3 border rounded-md bg-destructive/5"
                  data-testid={`alert-out-of-stock-${product.id}`}
                >
                  <div className="flex-1">
                    <div className="font-medium">{product.name}</div>
                    <div className="text-sm text-muted-foreground">{product.code}</div>
                  </div>
                  <Badge variant="destructive">Out of Stock</Badge>
                  <Button
                    onClick={() => {
                      setRestockingProduct(product);
                      setRestockQuantity("");
                    }}
                    size="sm"
                    className="ml-4"
                    data-testid={`button-restock-${product.id}`}
                  >
                    Restock
                  </Button>
                </div>
              ))}
              {lowStockProducts.map((product) => (
                <div
                  key={product.id}
                  className="flex items-center justify-between p-3 border rounded-md bg-yellow-50 dark:bg-yellow-950/20"
                  data-testid={`alert-low-stock-${product.id}`}
                >
                  <div className="flex-1">
                    <div className="font-medium">{product.name}</div>
                    <div className="text-sm text-muted-foreground">{product.code}</div>
                  </div>
                  <Badge variant="secondary">Low Stock: {product.currentStock}</Badge>
                  <Button
                    onClick={() => {
                      setRestockingProduct(product);
                      setRestockQuantity("");
                    }}
                    size="sm"
                    className="ml-4"
                    data-testid={`button-restock-${product.id}`}
                  >
                    Restock
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>All Products</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Code</TableHead>
                <TableHead>Name</TableHead>
                <TableHead className="text-right">Current Stock</TableHead>
                <TableHead className="text-right">Low Stock Alert</TableHead>
                <TableHead className="text-right">Unit Price</TableHead>
                <TableHead className="text-right">Total Value</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {products.map((product) => (
                <TableRow key={product.id} data-testid={`row-product-${product.id}`}>
                  <TableCell className="font-medium">{product.code}</TableCell>
                  <TableCell>{product.name}</TableCell>
                  <TableCell className="text-right">
                    <span
                      className={
                        product.currentStock === 0
                          ? "text-destructive font-semibold"
                          : product.currentStock <= product.lowStockThreshold
                          ? "text-yellow-600 dark:text-yellow-500 font-semibold"
                          : ""
                      }
                    >
                      {product.currentStock}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">{product.lowStockThreshold}</TableCell>
                  <TableCell className="text-right">${product.price.toFixed(2)}</TableCell>
                  <TableCell className="text-right">
                    ${(product.currentStock * product.price).toFixed(2)}
                  </TableCell>
                  <TableCell>
                    <Button
                      onClick={() => {
                        setRestockingProduct(product);
                        setRestockQuantity("");
                      }}
                      size="sm"
                      variant="outline"
                      data-testid={`button-restock-table-${product.id}`}
                    >
                      Restock
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={!!restockingProduct} onOpenChange={() => setRestockingProduct(null)}>
        <DialogContent data-testid="dialog-restock">
          <DialogHeader>
            <DialogTitle>Restock Product</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {restockingProduct && (
              <>
                <div>
                  <div className="font-medium text-lg">{restockingProduct.name}</div>
                  <div className="text-sm text-muted-foreground">{restockingProduct.code}</div>
                  <div className="text-sm text-muted-foreground mt-1">
                    Current Stock: {restockingProduct.currentStock} units
                  </div>
                </div>
                <div>
                  <Label htmlFor="restock-quantity">Quantity to Add</Label>
                  <Input
                    id="restock-quantity"
                    type="number"
                    min="1"
                    value={restockQuantity}
                    onChange={(e) => setRestockQuantity(e.target.value)}
                    placeholder="Enter quantity"
                    autoFocus
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        handleRestock();
                      }
                    }}
                    data-testid="input-restock-quantity"
                  />
                </div>
                <Button className="w-full" onClick={handleRestock} data-testid="button-confirm-restock">
                  Add to Stock
                </Button>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
