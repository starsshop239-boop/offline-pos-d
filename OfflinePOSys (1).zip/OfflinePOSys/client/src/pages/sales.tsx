import { useState } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { getProducts, updateProduct, addSale } from "@/lib/localStorage";
import { Product, SaleItem } from "@shared/schema";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Receipt } from "@/components/receipt";
import { useStore } from "@/lib/store-context";
import { NumericKeypad } from "@/components/numeric-keypad";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

export default function SalesPage() {
  const { products, refreshProducts, refreshSales } = useStore();
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [quantity, setQuantity] = useState("");
  const [cart, setCart] = useState<SaleItem[]>([]);
  const [showReceipt, setShowReceipt] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [paymentType, setPaymentType] = useState<"cash" | "debt">("cash");
  const [currentSale, setCurrentSale] = useState<any>(null);
  const { toast } = useToast();

  const handleProductClick = (product: Product) => {
    if (product.currentStock === 0) {
      toast({
        title: "Out of Stock",
        description: `${product.name} is currently out of stock.`,
        variant: "destructive",
      });
      return;
    }
    setSelectedProduct(product);
    setQuantity("");
  };

  const handleAddToCart = () => {
    if (!selectedProduct || !quantity) return;

    const qty = parseInt(quantity);
    if (qty <= 0 || isNaN(qty)) {
      toast({
        title: "Invalid Quantity",
        description: "Please enter a valid quantity.",
        variant: "destructive",
      });
      return;
    }

    if (qty > selectedProduct.currentStock) {
      toast({
        title: "Insufficient Stock",
        description: `Only ${selectedProduct.currentStock} units available.`,
        variant: "destructive",
      });
      return;
    }

    const existingItem = cart.find(item => item.productId === selectedProduct.id);
    
    if (existingItem) {
      const newQty = existingItem.quantity + qty;
      if (newQty > selectedProduct.currentStock) {
        toast({
          title: "Insufficient Stock",
          description: `Only ${selectedProduct.currentStock} units available.`,
          variant: "destructive",
        });
        return;
      }
      setCart(cart.map(item =>
        item.productId === selectedProduct.id
          ? { ...item, quantity: newQty, totalPrice: newQty * item.unitPrice }
          : item
      ));
    } else {
      const newItem: SaleItem = {
        productId: selectedProduct.id,
        productCode: selectedProduct.code,
        productName: selectedProduct.name,
        quantity: qty,
        unitPrice: selectedProduct.price,
        unitCost: selectedProduct.costPrice,
        totalPrice: qty * selectedProduct.price,
      };
      setCart([...cart, newItem]);
    }

    setSelectedProduct(null);
    setQuantity("");
    
    toast({
      title: "Added to Cart",
      description: `${qty} × ${selectedProduct.name}`,
    });
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart(cart.filter(item => item.productId !== productId));
  };

  const handleInitiateCheckout = () => {
    if (cart.length === 0) {
      toast({
        title: "Empty Cart",
        description: "Please add items to cart before checkout.",
        variant: "destructive",
      });
      return;
    }
    setPaymentType("cash");
    setShowCheckout(true);
  };

  const handleConfirmCheckout = () => {
    const freshProducts = getProducts();
    
    for (const item of cart) {
      const product = freshProducts.find(p => p.id === item.productId);
      if (!product) {
        toast({
          title: "Error",
          description: `Product ${item.productName} no longer exists.`,
          variant: "destructive",
        });
        return;
      }
      if (product.currentStock < item.quantity) {
        toast({
          title: "Insufficient Stock",
          description: `${product.name} only has ${product.currentStock} units available.`,
          variant: "destructive",
        });
        return;
      }
    }

    const subtotal = cart.reduce((sum, item) => sum + item.totalPrice, 0);
    const total = subtotal;

    const sale = {
      id: Date.now().toString(),
      items: cart,
      subtotal,
      total,
      paymentType,
      isPaid: paymentType === "cash",
      date: new Date().toISOString(),
    };

    cart.forEach(item => {
      const product = freshProducts.find(p => p.id === item.productId);
      if (product) {
        updateProduct(product.id, {
          currentStock: product.currentStock - item.quantity,
        });
      }
    });

    addSale(sale);
    refreshProducts();
    refreshSales();
    
    setCurrentSale(sale);
    setShowCheckout(false);
    setShowReceipt(true);
    setCart([]);

    toast({
      title: "Sale Completed",
      description: `Payment: ${paymentType === "cash" ? "Cash" : "Debt"}`,
    });
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.totalPrice, 0);

  return (
    <div className="flex h-full gap-6">
      <div className="flex-1 flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-semibold" data-testid="text-page-title">Sales</h1>
        </div>

        <ScrollArea className="flex-1">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4 pb-4">
            {products.map((product) => (
              <Card
                key={product.id}
                className="aspect-square p-6 flex flex-col items-center justify-center gap-3 cursor-pointer hover-elevate active-elevate-2"
                onClick={() => handleProductClick(product)}
                data-testid={`card-product-${product.id}`}
              >
                <div className="text-sm text-muted-foreground" data-testid={`text-code-${product.id}`}>
                  {product.code}
                </div>
                <div className="text-base font-medium text-center" data-testid={`text-name-${product.id}`}>
                  {product.name}
                </div>
                <div className="text-lg font-semibold" data-testid={`text-price-${product.id}`}>
                  ${product.price.toFixed(2)}
                </div>
                <Badge
                  variant={product.currentStock === 0 ? "destructive" : product.currentStock <= product.lowStockThreshold ? "secondary" : "outline"}
                  data-testid={`badge-stock-${product.id}`}
                >
                  Stock: {product.currentStock}
                </Badge>
              </Card>
            ))}
          </div>
        </ScrollArea>
      </div>

      <Card className="w-96 p-6 flex flex-col gap-4">
        <h2 className="text-xl font-semibold" data-testid="text-cart-title">Cart</h2>
        
        <ScrollArea className="flex-1 -mx-6 px-6">
          {cart.length === 0 ? (
            <div className="text-center text-muted-foreground py-12" data-testid="text-empty-cart">
              Cart is empty
            </div>
          ) : (
            <div className="space-y-3">
              {cart.map((item) => (
                <Card key={item.productId} className="p-4" data-testid={`cart-item-${item.productId}`}>
                  <div className="flex justify-between items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate" data-testid={`text-cart-item-name-${item.productId}`}>
                        {item.productName}
                      </div>
                      <div className="text-sm text-muted-foreground" data-testid={`text-cart-item-code-${item.productId}`}>
                        {item.productCode}
                      </div>
                      <div className="text-sm mt-1" data-testid={`text-cart-item-qty-${item.productId}`}>
                        {item.quantity} × ${item.unitPrice.toFixed(2)}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <div className="font-semibold" data-testid={`text-cart-item-total-${item.productId}`}>
                        ${item.totalPrice.toFixed(2)}
                      </div>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleRemoveFromCart(item.productId)}
                        data-testid={`button-remove-${item.productId}`}
                      >
                        Remove
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </ScrollArea>

        <div className="space-y-4 pt-4 border-t">
          <div className="flex justify-between items-center">
            <span className="text-lg font-medium">Total:</span>
            <span className="text-2xl font-bold" data-testid="text-cart-total">
              ${cartTotal.toFixed(2)}
            </span>
          </div>

          <Button
            className="w-full"
            size="lg"
            onClick={handleInitiateCheckout}
            disabled={cart.length === 0}
            data-testid="button-checkout"
          >
            Proceed to Checkout
          </Button>
        </div>
      </Card>

      <Dialog open={!!selectedProduct} onOpenChange={() => setSelectedProduct(null)}>
        <DialogContent className="max-w-md" data-testid="dialog-quantity">
          <DialogHeader>
            <DialogTitle>Enter Quantity</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {selectedProduct && (
              <>
                <div>
                  <div className="font-medium text-lg">{selectedProduct.name}</div>
                  <div className="text-sm text-muted-foreground">{selectedProduct.code}</div>
                  <div className="text-sm text-muted-foreground mt-1">
                    Available: {selectedProduct.currentStock} units
                  </div>
                  <div className="text-lg font-semibold mt-2">
                    ${selectedProduct.price.toFixed(2)} per unit
                  </div>
                </div>
                <NumericKeypad
                  value={quantity}
                  onChange={setQuantity}
                  onConfirm={handleAddToCart}
                />
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showCheckout} onOpenChange={setShowCheckout}>
        <DialogContent className="max-w-md" data-testid="dialog-checkout">
          <DialogHeader>
            <DialogTitle>Select Payment Method</DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            <div className="space-y-4">
              <div className="flex justify-between text-lg">
                <span className="font-medium">Total Amount:</span>
                <span className="font-bold text-2xl" data-testid="checkout-total">
                  ${cartTotal.toFixed(2)}
                </span>
              </div>

              <RadioGroup value={paymentType} onValueChange={(v: any) => setPaymentType(v)}>
                <div className="flex items-center space-x-3 p-4 border rounded-lg hover-elevate cursor-pointer" onClick={() => setPaymentType("cash")}>
                  <RadioGroupItem value="cash" id="cash" data-testid="radio-cash" />
                  <Label htmlFor="cash" className="flex-1 cursor-pointer">
                    <div className="font-medium">Cash Payment</div>
                    <div className="text-sm text-muted-foreground">Paid immediately</div>
                  </Label>
                </div>
                <div className="flex items-center space-x-3 p-4 border rounded-lg hover-elevate cursor-pointer" onClick={() => setPaymentType("debt")}>
                  <RadioGroupItem value="debt" id="debt" data-testid="radio-debt" />
                  <Label htmlFor="debt" className="flex-1 cursor-pointer">
                    <div className="font-medium">Debt (Unpaid)</div>
                    <div className="text-sm text-muted-foreground">Record as debt for later payment</div>
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setShowCheckout(false)}
                data-testid="button-cancel-checkout"
              >
                Cancel
              </Button>
              <Button
                className="flex-1"
                onClick={handleConfirmCheckout}
                data-testid="button-confirm-checkout"
              >
                Confirm Sale
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {showReceipt && currentSale && (
        <Receipt
          sale={currentSale}
          onClose={() => {
            setShowReceipt(false);
            setCurrentSale(null);
          }}
        />
      )}
    </div>
  );
}
