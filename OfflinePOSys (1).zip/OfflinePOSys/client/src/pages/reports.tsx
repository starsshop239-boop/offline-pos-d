import { useMemo } from "react";
import { useState } from "react";
import { TrendingUp, DollarSign, Package, ShoppingCart } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ProductPerformance } from "@shared/schema";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStore } from "@/lib/store-context";

export default function ReportsPage() {
  const [timeRange, setTimeRange] = useState<"7" | "30" | "90" | "365">("30");
  const { products, sales } = useStore();

  const analytics = useMemo(() => {
    const now = new Date();
    const daysAgo = parseInt(timeRange);
    const startDate = new Date(now.getTime() - daysAgo * 24 * 60 * 60 * 1000);

    const filteredSales = sales.filter((sale) => new Date(sale.date) >= startDate);

    const totalRevenue = filteredSales.reduce((sum, sale) => sum + sale.total, 0);
    const totalTransactions = filteredSales.length;
    const debtTransactions = filteredSales.filter((s) => !s.isPaid).length;
    const totalDebt = filteredSales.filter((s) => !s.isPaid).reduce((sum, sale) => sum + sale.total, 0);

    let totalCost = 0;
    filteredSales.forEach((sale) => {
      sale.items.forEach((item) => {
        totalCost += item.unitCost * item.quantity;
      });
    });

    const totalProfit = totalRevenue - totalCost;

    const productPerformance: ProductPerformance[] = [];
    const productStats = new Map<
      string,
      { code: string; name: string; unitsSold: number; revenue: number; cost: number; currentStock: number }
    >();

    filteredSales.forEach((sale) => {
      sale.items.forEach((item) => {
        const existing = productStats.get(item.productId) || {
          code: item.productCode,
          name: item.productName,
          unitsSold: 0,
          revenue: 0,
          cost: 0,
          currentStock: 0,
        };
        existing.unitsSold += item.quantity;
        existing.revenue += item.totalPrice;
        existing.cost += item.unitCost * item.quantity;
        productStats.set(item.productId, existing);
      });
    });

    products.forEach((product) => {
      const stats = productStats.get(product.id);
      if (stats) {
        stats.currentStock = product.currentStock;
      }
    });

    productStats.forEach((stats, productId) => {
      productPerformance.push({
        productId,
        productCode: stats.code,
        productName: stats.name,
        unitsSold: stats.unitsSold,
        revenue: stats.revenue,
        profit: stats.revenue - stats.cost,
        currentStock: stats.currentStock,
      });
    });

    productPerformance.sort((a, b) => b.unitsSold - a.unitsSold);

    const dailyData = new Map<string, { revenue: number; profit: number; sales: number }>();
    filteredSales.forEach((sale) => {
      const dateKey = new Date(sale.date).toLocaleDateString();
      const existing = dailyData.get(dateKey) || { revenue: 0, profit: 0, sales: 0 };
      
      let saleCost = 0;
      sale.items.forEach((item) => {
        saleCost += item.unitCost * item.quantity;
      });
      
      existing.revenue += sale.total;
      existing.profit += sale.total - saleCost;
      existing.sales += 1;
      dailyData.set(dateKey, existing);
    });

    const chartData = Array.from(dailyData.entries())
      .map(([date, data]) => ({
        date,
        revenue: parseFloat(data.revenue.toFixed(2)),
        profit: parseFloat(data.profit.toFixed(2)),
        sales: data.sales,
      }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(-30);

    return {
      totalRevenue,
      totalProfit,
      totalCost,
      totalTransactions,
      debtTransactions,
      totalDebt,
      productPerformance,
      chartData,
    };
  }, [sales, products, timeRange]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-semibold" data-testid="text-page-title">Reports & Analytics</h1>
        <Select value={timeRange} onValueChange={(value: any) => setTimeRange(value)}>
          <SelectTrigger className="w-48" data-testid="select-time-range">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">Last 7 Days</SelectItem>
            <SelectItem value="30">Last 30 Days</SelectItem>
            <SelectItem value="90">Last 90 Days</SelectItem>
            <SelectItem value="365">Last Year</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-total-revenue">
              ${analytics.totalRevenue.toFixed(2)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Profit</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary" data-testid="text-total-profit">
              ${analytics.totalProfit.toFixed(2)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-total-transactions">
              {analytics.totalTransactions}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Debt</CardTitle>
            <DollarSign className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive" data-testid="text-total-debt">
              ${analytics.totalDebt.toFixed(2)}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              {analytics.debtTransactions} unpaid transactions
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="sales-trend" className="space-y-4">
        <TabsList>
          <TabsTrigger value="sales-trend" data-testid="tab-sales-trend">Sales Trend</TabsTrigger>
          <TabsTrigger value="product-performance" data-testid="tab-product-performance">
            Product Performance
          </TabsTrigger>
          <TabsTrigger value="profit-loss" data-testid="tab-profit-loss">Profit & Loss</TabsTrigger>
        </TabsList>

        <TabsContent value="sales-trend" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sales Growth Chart</CardTitle>
            </CardHeader>
            <CardContent>
              {analytics.chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={analytics.chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="date" 
                      fontSize={12}
                      angle={-45}
                      textAnchor="end"
                      height={80}
                    />
                    <YAxis fontSize={12} />
                    <Tooltip />
                    <Line
                      type="monotone"
                      dataKey="revenue"
                      stroke="hsl(var(--chart-1))"
                      strokeWidth={2}
                      name="Revenue ($)"
                      dot={{ r: 3 }}
                    />
                    <Line
                      type="monotone"
                      dataKey="profit"
                      stroke="hsl(var(--chart-2))"
                      strokeWidth={2}
                      name="Profit ($)"
                      dot={{ r: 3 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[400px] flex items-center justify-center text-muted-foreground">
                  No sales data available for the selected period
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="product-performance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Best Selling Products</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Rank</TableHead>
                    <TableHead>Code</TableHead>
                    <TableHead>Product Name</TableHead>
                    <TableHead className="text-right">Units Sold</TableHead>
                    <TableHead className="text-right">Revenue</TableHead>
                    <TableHead className="text-right">Profit</TableHead>
                    <TableHead className="text-right">Current Stock</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {analytics.productPerformance.map((product, index) => (
                    <TableRow key={product.productId} data-testid={`row-performance-${product.productId}`}>
                      <TableCell className="font-medium">{index + 1}</TableCell>
                      <TableCell>{product.productCode}</TableCell>
                      <TableCell>{product.productName}</TableCell>
                      <TableCell className="text-right font-semibold">{product.unitsSold}</TableCell>
                      <TableCell className="text-right">${product.revenue.toFixed(2)}</TableCell>
                      <TableCell className="text-right text-primary">
                        ${product.profit.toFixed(2)}
                      </TableCell>
                      <TableCell className="text-right">{product.currentStock}</TableCell>
                    </TableRow>
                  ))}
                  {analytics.productPerformance.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                        No sales data available
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="profit-loss" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold" data-testid="text-pl-revenue">
                  ${analytics.totalRevenue.toFixed(2)}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium">Total Cost</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-destructive" data-testid="text-pl-cost">
                  ${analytics.totalCost.toFixed(2)}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-primary" data-testid="text-pl-profit">
                  ${analytics.totalProfit.toFixed(2)}
                </div>
                <div className="text-sm text-muted-foreground mt-2">
                  Margin: {analytics.totalRevenue > 0 ? ((analytics.totalProfit / analytics.totalRevenue) * 100).toFixed(1) : 0}%
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Profit Breakdown by Product</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead className="text-right">Revenue</TableHead>
                    <TableHead className="text-right">Cost</TableHead>
                    <TableHead className="text-right">Profit</TableHead>
                    <TableHead className="text-right">Margin</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {analytics.productPerformance.map((product) => {
                    const cost = product.revenue - product.profit;
                    const margin = product.revenue > 0 ? (product.profit / product.revenue) * 100 : 0;
                    return (
                      <TableRow key={product.productId}>
                        <TableCell>
                          <div className="font-medium">{product.productName}</div>
                          <div className="text-sm text-muted-foreground">{product.productCode}</div>
                        </TableCell>
                        <TableCell className="text-right">${product.revenue.toFixed(2)}</TableCell>
                        <TableCell className="text-right">${cost.toFixed(2)}</TableCell>
                        <TableCell className="text-right font-semibold text-primary">
                          ${product.profit.toFixed(2)}
                        </TableCell>
                        <TableCell className="text-right">{margin.toFixed(1)}%</TableCell>
                      </TableRow>
                    );
                  })}
                  {analytics.productPerformance.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                        No sales data available
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
