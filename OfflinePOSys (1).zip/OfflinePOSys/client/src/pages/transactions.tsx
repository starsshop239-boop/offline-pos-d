import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStore } from "@/lib/store-context";

export default function TransactionsPage() {
  const [filter, setFilter] = useState<"all" | "cash" | "debt">("all");
  const { sales } = useStore();
  
  const sortedSales = [...sales].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const filteredSales = sortedSales.filter((sale) => {
    if (filter === "all") return true;
    if (filter === "cash") return sale.isPaid;
    if (filter === "debt") return !sale.isPaid;
    return true;
  });

  const totalAmount = filteredSales.reduce((sum, sale) => sum + sale.total, 0);
  const paidAmount = filteredSales.filter((s) => s.isPaid).reduce((sum, sale) => sum + sale.total, 0);
  const debtAmount = filteredSales.filter((s) => !s.isPaid).reduce((sum, sale) => sum + sale.total, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-semibold" data-testid="text-page-title">Transaction History</h1>
        <Select value={filter} onValueChange={(value: any) => setFilter(value)}>
          <SelectTrigger className="w-48" data-testid="select-filter">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Transactions</SelectItem>
            <SelectItem value="cash">Cash Only</SelectItem>
            <SelectItem value="debt">Debt Only</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-transaction-count">
              {filteredSales.length}
            </div>
            <div className="text-sm text-muted-foreground mt-1">
              Amount: ${totalAmount.toFixed(2)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Paid (Cash)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary" data-testid="text-paid-amount">
              ${paidAmount.toFixed(2)}
            </div>
            <div className="text-sm text-muted-foreground mt-1">
              {filteredSales.filter((s) => s.isPaid).length} transactions
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Unpaid (Debt)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive" data-testid="text-debt-amount">
              ${debtAmount.toFixed(2)}
            </div>
            <div className="text-sm text-muted-foreground mt-1">
              {filteredSales.filter((s) => !s.isPaid).length} transactions
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {filteredSales.map((sale) => (
              <Collapsible key={sale.id}>
                <Card data-testid={`card-transaction-${sale.id}`}>
                  <CollapsibleTrigger className="w-full">
                    <div className="p-4 flex items-center justify-between hover-elevate">
                      <div className="flex items-center gap-4">
                        <div className="text-left">
                          <div className="font-medium" data-testid={`text-transaction-date-${sale.id}`}>
                            {new Date(sale.date).toLocaleString()}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {sale.items.length} item{sale.items.length > 1 ? "s" : ""}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <div className="font-bold text-lg" data-testid={`text-transaction-total-${sale.id}`}>
                            ${sale.total.toFixed(2)}
                          </div>
                          <Badge
                            variant={sale.isPaid ? "outline" : "destructive"}
                            data-testid={`badge-payment-${sale.id}`}
                          >
                            {sale.isPaid ? "Cash" : "Debt"}
                          </Badge>
                        </div>
                        <ChevronDown className="w-4 h-4" />
                      </div>
                    </div>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <div className="px-4 pb-4 pt-2 border-t">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Product</TableHead>
                            <TableHead className="text-right">Qty</TableHead>
                            <TableHead className="text-right">Unit Price</TableHead>
                            <TableHead className="text-right">Total</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {sale.items.map((item, index) => (
                            <TableRow key={index}>
                              <TableCell>
                                <div className="font-medium">{item.productName}</div>
                                <div className="text-sm text-muted-foreground">{item.productCode}</div>
                              </TableCell>
                              <TableCell className="text-right">{item.quantity}</TableCell>
                              <TableCell className="text-right">${item.unitPrice.toFixed(2)}</TableCell>
                              <TableCell className="text-right font-medium">
                                ${item.totalPrice.toFixed(2)}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                      <div className="mt-3 pt-3 border-t flex justify-between items-center">
                        <span className="font-medium">Total:</span>
                        <span className="text-xl font-bold">${sale.total.toFixed(2)}</span>
                      </div>
                    </div>
                  </CollapsibleContent>
                </Card>
              </Collapsible>
            ))}
            {filteredSales.length === 0 && (
              <div className="text-center text-muted-foreground py-12" data-testid="text-no-transactions">
                No transactions found
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
