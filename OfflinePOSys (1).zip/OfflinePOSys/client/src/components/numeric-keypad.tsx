import { Button } from "@/components/ui/button";
import { Delete } from "lucide-react";

interface NumericKeypadProps {
  value: string;
  onChange: (value: string) => void;
  onConfirm: () => void;
}

export function NumericKeypad({ value, onChange, onConfirm }: NumericKeypadProps) {
  const handleNumberClick = (num: string) => {
    onChange(value + num);
  };

  const handleDelete = () => {
    onChange(value.slice(0, -1));
  };

  const handleClear = () => {
    onChange("");
  };

  return (
    <div className="space-y-4">
      <div className="bg-muted rounded-lg p-4 text-right">
        <div className="text-4xl font-bold tabular-nums min-h-[3rem] flex items-center justify-end" data-testid="keypad-display">
          {value || "0"}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((num) => (
          <Button
            key={num}
            size="lg"
            variant="outline"
            className="h-16 text-2xl font-semibold"
            onClick={() => handleNumberClick(num)}
            data-testid={`keypad-${num}`}
          >
            {num}
          </Button>
        ))}
        <Button
          size="lg"
          variant="outline"
          className="h-16 text-xl font-semibold"
          onClick={handleClear}
          data-testid="keypad-clear"
        >
          C
        </Button>
        <Button
          size="lg"
          variant="outline"
          className="h-16 text-2xl font-semibold"
          onClick={() => handleNumberClick("0")}
          data-testid="keypad-0"
        >
          0
        </Button>
        <Button
          size="lg"
          variant="outline"
          className="h-16"
          onClick={handleDelete}
          data-testid="keypad-delete"
        >
          <Delete className="w-6 h-6" />
        </Button>
      </div>

      <Button
        size="lg"
        className="w-full h-14 text-lg font-semibold"
        onClick={onConfirm}
        disabled={!value || value === "0"}
        data-testid="keypad-confirm"
      >
        Confirm
      </Button>
    </div>
  );
}
