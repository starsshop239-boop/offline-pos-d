import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Sale } from "@shared/schema";
import { Separator } from "@/components/ui/separator";

interface ReceiptProps {
  sale: Sale;
  onClose: () => void;
}

export function Receipt({ sale, onClose }: ReceiptProps) {
  const handleSave = () => {
    const receiptContent = generateReceiptText(sale);
    const blob = new Blob([receiptContent], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `receipt-${sale.id}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-md" data-testid="dialog-receipt">
        <DialogHeader>
          <DialogTitle>Receipt</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="text-center">
            <div className="text-2xl font-bold">POS System</div>
            <div className="text-sm text-muted-foreground mt-1">
              {new Date(sale.date).toLocaleString()}
            </div>
          </div>

          <Separator />

          <div className="space-y-2">
            {sale.items.map((item, index) => (
              <div key={index} className="flex justify-between text-sm" data-testid={`receipt-item-${index}`}>
                <div className="flex-1">
                  <div className="font-medium">{item.productName}</div>
                  <div className="text-muted-foreground">
                    {item.quantity} × ${item.unitPrice.toFixed(2)}
                  </div>
                </div>
                <div className="font-medium">${item.totalPrice.toFixed(2)}</div>
              </div>
            ))}
          </div>

          <Separator />

          <div className="space-y-1">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span data-testid="receipt-subtotal">${sale.subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-lg font-bold">
              <span>Total:</span>
              <span data-testid="receipt-total">${sale.total.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Payment:</span>
              <span data-testid="receipt-payment" className={sale.isPaid ? "" : "text-destructive"}>
                {sale.isPaid ? "Cash (Paid)" : "Debt (Unpaid)"}
              </span>
            </div>
          </div>

          <Separator />

          <div className="text-center text-sm text-muted-foreground">
            Thank you for your business!
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose} data-testid="button-close-receipt">
            Don't Save
          </Button>
          <Button
            onClick={() => {
              handleSave();
              onClose();
            }}
            data-testid="button-save-receipt"
          >
            Save Receipt
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function generateReceiptText(sale: Sale): string {
  let text = "========================================\n";
  text += "           POS SYSTEM RECEIPT           \n";
  text += "========================================\n\n";
  text += `Date: ${new Date(sale.date).toLocaleString()}\n`;
  text += `Transaction ID: ${sale.id}\n\n`;
  text += "----------------------------------------\n";
  text += "ITEMS:\n";
  text += "----------------------------------------\n\n";

  sale.items.forEach((item) => {
    text += `${item.productName}\n`;
    text += `  Code: ${item.productCode}\n`;
    text += `  ${item.quantity} × $${item.unitPrice.toFixed(2)} = $${item.totalPrice.toFixed(2)}\n\n`;
  });

  text += "----------------------------------------\n";
  text += `Subtotal:        $${sale.subtotal.toFixed(2)}\n`;
  text += `Total:           $${sale.total.toFixed(2)}\n`;
  text += `Payment Method:  ${sale.isPaid ? "Cash (Paid)" : "Debt (Unpaid)"}\n`;
  text += "----------------------------------------\n\n";
  text += "     Thank you for your business!      \n";
  text += "========================================\n";

  return text;
}
