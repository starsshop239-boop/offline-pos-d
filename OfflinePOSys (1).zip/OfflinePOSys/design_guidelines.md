# Design Guidelines: Offline POS System

## Design Approach
**System Selected:** Material Design with modifications for touch-friendly business operations
**Rationale:** This utility-focused POS system prioritizes efficiency, data clarity, and ease of use for cashiers. Material Design provides robust patterns for data-dense interfaces while maintaining visual clarity.

## Typography System

**Primary Font:** Inter (via Google Fonts CDN)
- Display/Headers: 600 weight, sizes: text-3xl to text-5xl
- Section Titles: 600 weight, text-xl to text-2xl  
- Body Text: 400 weight, text-base to text-lg
- Labels/Captions: 500 weight, text-sm to text-base
- Numbers/Data: 600 weight (tabular-nums class for alignment)

**Hierarchy:**
- Page Headers: text-3xl, font-semibold
- Card Titles: text-xl, font-semibold
- Product Names: text-base, font-medium
- Data Labels: text-sm, font-medium
- Body Content: text-base, font-normal

## Layout System

**Spacing Primitives:** Use Tailwind units of **2, 4, 6, 8, 12, and 16**
- Component padding: p-4, p-6
- Section spacing: space-y-6, space-y-8
- Grid gaps: gap-4, gap-6
- Card padding: p-6
- Form fields: space-y-4

**Container Structure:**
- Main container: max-w-7xl mx-auto px-4
- Dashboard grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Product grid: grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6

## Component Library

### Navigation
- Sidebar navigation (fixed left, w-64) with icon + label menu items
- Top bar showing business name, current date/time, user info
- Mobile: Bottom tab bar with primary functions

### Product Grid
- Square tiles: aspect-square with rounded-lg borders
- Each tile: Product code (top, small), Product name (center, prominent), Stock count (bottom, badge)
- Touch target: min-h-32 for easy tapping
- Hover state: subtle elevation increase

### Forms & Inputs
- Input fields: rounded-lg, p-3, with clear labels above
- Quantity input: Large numeric input with +/- buttons flanking
- Add product form: Single column, generous spacing between fields
- Buttons: Full width on mobile, auto width on desktop

### Data Display
- Sales cards: White background, rounded-lg, shadow-sm, p-6
- Stat displays: Large number (text-4xl, font-bold), label below (text-sm)
- Tables: Striped rows, sticky headers, responsive scroll
- Charts: Line charts using Chart.js, minimum height h-64, clean grid lines

### Modals & Popups
- Quantity input modal: Centered, max-w-sm, large numeric keypad
- Receipt preview: max-w-md, scrollable content
- Confirmation dialogs: Compact with clear action buttons

### Buttons
- Primary: Solid fill, rounded-lg, px-6 py-3, font-medium
- Secondary: Outlined, same padding
- Danger: For delete/critical actions
- Icon buttons: Rounded-full, p-2 for compact actions

### Status Indicators
- Low stock warning: Badge with warning styling
- Debt indicator: Distinctive badge on transactions
- Payment status: Clear paid/unpaid visual distinction
- Stock levels: Color-coded (green: good, yellow: low, red: critical)

### Reports Section
- Dashboard cards in responsive grid
- Line chart: Full width, h-80, showing monthly trends
- Product performance table: Sortable columns for sales analysis
- Date range picker: Prominent, easy to adjust timeframes

## Key Interaction Patterns

**Product Selection Flow:**
1. Tap product tile → Immediate visual feedback (scale animation)
2. Modal appears with large quantity input
3. Numeric keypad for quick entry
4. Confirm button prominent at bottom

**Navigation:**
- Primary sections: Sales, Products, Reports, Inventory, Settings
- Always visible navigation (sidebar/bottom tabs)
- Clear active state indication

**Data Entry:**
- Auto-focus on first input field
- Enter key advances to next field
- Large touch targets (min 44x44px)

## Visual Principles
- **Clarity over decoration:** Minimize visual noise
- **Touch-first design:** Large tap targets, adequate spacing
- **Data hierarchy:** Most important metrics prominent
- **Consistent spacing:** Maintain rhythm throughout
- **Responsive behavior:** Stack on mobile, expand on desktop

## Images
**No hero images required** - This is a functional business tool, not a marketing interface. Focus on clean data presentation and intuitive workflows.