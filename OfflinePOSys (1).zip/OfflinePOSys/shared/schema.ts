import { z } from "zod";

// Product Schema
export const productSchema = z.object({
  id: z.string(),
  code: z.string().min(1, "Product code is required"),
  name: z.string().min(1, "Product name is required"),
  price: z.number().positive("Price must be positive"),
  costPrice: z.number().positive("Cost price must be positive"),
  currentStock: z.number().int().nonnegative("Stock cannot be negative"),
  lowStockThreshold: z.number().int().nonnegative("Threshold cannot be negative"),
});

export const insertProductSchema = productSchema.omit({ id: true });

export type Product = z.infer<typeof productSchema>;
export type InsertProduct = z.infer<typeof insertProductSchema>;

// Sale Item Schema
export const saleItemSchema = z.object({
  productId: z.string(),
  productCode: z.string(),
  productName: z.string(),
  quantity: z.number().int().positive(),
  unitPrice: z.number().positive(),
  unitCost: z.number().positive(),
  totalPrice: z.number().positive(),
});

export type SaleItem = z.infer<typeof saleItemSchema>;

// Sale/Transaction Schema
export const saleSchema = z.object({
  id: z.string(),
  items: z.array(saleItemSchema),
  subtotal: z.number(),
  total: z.number(),
  paymentType: z.enum(["cash", "debt"]),
  isPaid: z.boolean(),
  date: z.string(),
  customerName: z.string().optional(),
});

export const insertSaleSchema = saleSchema.omit({ id: true });

export type Sale = z.infer<typeof saleSchema>;
export type InsertSale = z.infer<typeof insertSaleSchema>;

// Restock Entry Schema
export const restockSchema = z.object({
  id: z.string(),
  productId: z.string(),
  productCode: z.string(),
  productName: z.string(),
  quantity: z.number().int().positive(),
  date: z.string(),
});

export type Restock = z.infer<typeof restockSchema>;

// Analytics Types
export type ProductPerformance = {
  productId: string;
  productCode: string;
  productName: string;
  unitsSold: number;
  revenue: number;
  profit: number;
  currentStock: number;
};

export type MonthlySales = {
  month: string;
  revenue: number;
  profit: number;
  unitsSold: number;
};

export type DailySales = {
  date: string;
  revenue: number;
  profit: number;
  sales: number;
};
